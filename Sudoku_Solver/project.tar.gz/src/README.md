
- **Sudoku_Generator.c**: Sudoku problems generator.

- **Sudoku_Solver.c**: Serial sudoku solver.

- **Sudoku_OpenMP.c**: Parallel Sudoku solver.

- **Sudoku_OpenMP_LL.c**: Parallel sudoku solver with linked lists instead of arrays.

- **Sudoku_Detector.c**: Sudoku solutions tester.

Input: num_boards is the number of sudoku problems.